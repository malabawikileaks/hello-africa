<?php
get_header();
if (have_posts()) :
    while (have_posts()) : the_post();
        get_template_part('template-parts/content', 'page');
    endwhile;
else :
    get_template_part('template-parts/content', 'none');
endif;
get_sidebar();
get_footer();
?>
<?php get_template_part('template-parts/content', 'page'); ?>



<?php hello_africa_breadcrumbs(); ?>
