<?php
get_header();
if (have_posts()) :
    while (have_posts()) : the_post();
        get_template_part('template-parts/content', 'single');
    endwhile;
    the_post_navigation();
    if (comments_open() || get_comments_number()) :
        comments_template();
    endif;
else :
    get_template_part('template-parts/content', 'none');
endif;
get_sidebar();
get_footer();
?>
<?php get_template_part('template-parts/content', 'single'); ?>



<?php hello_africa_breadcrumbs(); ?>
