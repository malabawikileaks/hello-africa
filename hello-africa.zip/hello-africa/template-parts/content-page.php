<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
    </header><!-- .entry-header -->

    <?php if (has_post_thumbnail()) : ?>
    <div class="page-thumbnail">
       <?php
if (has_post_thumbnail()) {
    $thumbnail_id = get_post_thumbnail_id();
    $thumbnail_url = wp_get_attachment_image_src($thumbnail_id, 'large')[0];
    echo '<img class="lazy-load" data-src="' . esc_url($thumbnail_url) . '" alt="' . esc_attr(get_the_title()) . '">';
}
?>

    </div><!-- .page-thumbnail -->
    <?php endif; ?>

    <div class="entry-content">
        <?php
        the_content();

        // Pagination for paginated content
        wp_link_pages([
            'before' => '<div class="page-links">' . __('Pages:', 'hello-africa'),
            'after'  => '</div>',
        ]);
        ?>
    </div><!-- .entry-content -->

    <footer class="entry-footer">
        <?php
        edit_post_link(__('Edit', 'hello-africa'), '<span class="edit-link">', '</span>');
        ?>
    </footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
