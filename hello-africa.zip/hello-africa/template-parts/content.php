<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php
        if (is_singular()) :
            the_title('<h1 class="entry-title">', '</h1>');
        else :
            the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
        endif;
        ?>

        <?php if ('post' === get_post_type()) : ?>
        <div class="entry-meta">
            <span class="posted-on"><?php echo get_the_date(); ?></span>
            <span class="author">by <?php the_author_posts_link(); ?></span>
        </div><!-- .entry-meta -->
        <?php endif; ?>
    </header><!-- .entry-header -->

    <?php if (has_post_thumbnail()) : ?>
    <div class="post-thumbnail">
        <a href="<?php the_permalink(); ?>">
            <?php
if (has_post_thumbnail()) {
    $thumbnail_id = get_post_thumbnail_id();
    $thumbnail_url = wp_get_attachment_image_src($thumbnail_id, 'large')[0];
    echo '<img class="lazy-load" data-src="' . esc_url($thumbnail_url) . '" alt="' . esc_attr(get_the_title()) . '">';
}
?>

        </a>
    </div><!-- .post-thumbnail -->
    <?php endif; ?>

    <div class="entry-content">
        <?php
        if (is_singular()) :
            the_content();
        else :
            the_excerpt();  // Display excerpt on archive and search pages
        endif;
        ?>
    </div><!-- .entry-content -->

    <footer class="entry-footer">
        <?php
        if ('post' === get_post_type()) :
            echo '<span class="category-links">' . get_the_category_list(', ') . '</span>';
        endif;
        ?>
        <span class="tags-links"><?php the_tags(); ?></span>
    </footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
