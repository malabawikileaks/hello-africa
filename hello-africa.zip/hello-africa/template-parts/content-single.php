<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title('<h1 class="entry-title">', '</h1>'); ?>

        <div class="entry-meta">
            <span class="posted-on"><?php echo get_the_date(); ?></span>
            <span class="author">by <?php the_author_posts_link(); ?></span>
            <span class="comments-link"><?php comments_popup_link(); ?></span>
        </div><!-- .entry-meta -->
    </header><!-- .entry-header -->

    <?php if (has_post_thumbnail()) : ?>
    <div class="post-thumbnail">
       <?php
if (has_post_thumbnail()) {
    $thumbnail_id = get_post_thumbnail_id();
    $thumbnail_url = wp_get_attachment_image_src($thumbnail_id, 'large')[0];
    echo '<img class="lazy-load" data-src="' . esc_url($thumbnail_url) . '" alt="' . esc_attr(get_the_title()) . '">';
}
?>

    </div><!-- .post-thumbnail -->
    <?php endif; ?>

    <div class="entry-content">
        <?php
        the_content();

        // Pagination for paginated posts
        wp_link_pages([
            'before' => '<div class="page-links">' . __('Pages:', 'hello-africa'),
            'after'  => '</div>',
        ]);
        ?>
    </div><!-- .entry-content -->

    <footer class="entry-footer">
        <?php
        echo '<span class="category-links">' . get_the_category_list(', ') . '</span>';
        echo '<span class="tags-links">' . get_the_tag_list('', ', ') . '</span>';
        ?>
    </footer><!-- .entry-footer -->

    <?php
    if (comments_open() || get_comments_number()) :
        comments_template();
    endif;
    ?>
</article><!-- #post-<?php the_ID(); ?> -->
