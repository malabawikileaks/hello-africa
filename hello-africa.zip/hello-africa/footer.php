<footer>
    <p>&copy; <?php echo date('Y'); ?> Hello Africa Theme by Ayeet Daniel Onyanga</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
