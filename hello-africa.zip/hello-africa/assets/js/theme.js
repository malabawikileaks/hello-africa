"use strict";

document.addEventListener("DOMContentLoaded", function () {
    
    /********* VARIABLES *********/
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const backToTopBtn = document.querySelector('.back-to-top');
    const header = document.querySelector('header');
    const searchInput = document.querySelector('#advanced-search-input');
    const searchResultsContainer = document.querySelector('#search-results');
    
    /********* DEBOUNCE FUNCTION *********/
    function debounce(func, wait = 20, immediate = true) {
        let timeout;
        return function() {
            const context = this, args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }
    
    /********* MOBILE MENU TOGGLE *********/
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
    }

    /********* STICKY HEADER *********/
    const stickyHeader = () => {
        if (window.scrollY > 100) {
            header.classList.add('sticky');
        } else {
            header.classList.remove('sticky');
        }
    };

    window.addEventListener('scroll', debounce(stickyHeader));

    /********* BACK TO TOP BUTTON *********/
    if (backToTopBtn) {
        window.addEventListener('scroll', debounce(function() {
            if (window.scrollY > 500) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        }));

        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    /********* LAZY LOADING IMAGES *********/
    const lazyLoadImages = document.querySelectorAll('img.lazy-load');
    if ('IntersectionObserver' in window) {
        let imageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    let image = entry.target;
                    image.src = image.dataset.src;
                    image.classList.remove('lazy-load');
                    imageObserver.unobserve(image);
                }
            });
        });

        lazyLoadImages.forEach(function(image) {
            imageObserver.observe(image);
        });
    } else {
        // Fallback for browsers without IntersectionObserver
        lazyLoadImages.forEach(function(image) {
            image.src = image.dataset.src;
        });
    }

    /********* INTERSECTION OBSERVER ANIMATIONS *********/
    const animateOnScrollElements = document.querySelectorAll('.animate-on-scroll');
    const animateOnScroll = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    animateOnScrollElements.forEach(element => {
        animateOnScroll.observe(element);
    });

    /********* ADVANCED SEARCH WITH AJAX *********/
    if (searchInput && searchResultsContainer) {
        searchInput.addEventListener('input', debounce(function() {
            const query = searchInput.value.trim();
            if (query.length > 2) {
                // Perform AJAX search request
                const xhr = new XMLHttpRequest();
                xhr.open('GET', `/wp-json/hello-africa/v1/search?s=${encodeURIComponent(query)}`, true);
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        const results = JSON.parse(xhr.responseText);
                        searchResultsContainer.innerHTML = ''; // Clear previous results
                        results.forEach(result => {
                            const resultItem = document.createElement('div');
                            resultItem.className = 'search-result-item';
                            resultItem.innerHTML = `
                                <a href="${result.url}">
                                    <h4>${result.title}</h4>
                                    <p>${result.excerpt}</p>
                                </a>`;
                            searchResultsContainer.appendChild(resultItem);
                        });
                    } else {
                        searchResultsContainer.innerHTML = '<p>No results found</p>';
                    }
                };
                xhr.send();
            } else {
                searchResultsContainer.innerHTML = ''; // Clear results if input is less than 3 chars
            }
        }, 300));
    }

    /********* SMOOTH SCROLL FOR ANCHOR LINKS *********/
    const smoothScroll = (target, duration) => {
        const targetElement = document.querySelector(target);
        if (!targetElement) return;
        const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY;
        const startPosition = window.pageYOffset;
        let startTime = null;

        const animation = (currentTime) => {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const run = easeInOutQuad(timeElapsed, startPosition, targetPosition, duration);
            window.scrollTo(0, run);
            if (timeElapsed < duration) requestAnimationFrame(animation);
        };

        const easeInOutQuad = (t, b, c, d) => {
            t /= d / 2;
            if (t < 1) return c / 2 * t * t + b;
            t--;
            return -c / 2 * (t * (t - 2) - 1) + b;
        };

        requestAnimationFrame(animation);
    };

    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href');
            smoothScroll(target, 800);  // Smooth scroll to target in 800ms
        });
    });

    /********* SIDEBAR TOGGLE FOR WIDGETS *********/
    const sidebarToggleBtn = document.querySelector('.sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    if (sidebarToggleBtn && sidebar) {
        sidebarToggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            document.body.classList.toggle('sidebar-open');
        });
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.getElementById('dark-mode-toggle');
    const body = document.body;

    toggle.addEventListener('click', function () {
        body.classList.toggle('dark-mode');
        localStorage.setItem('dark-mode', body.classList.contains('dark-mode'));
    });

    // Check localStorage for dark mode preference
    if (localStorage.getItem('dark-mode') === 'true') {
        body.classList.add('dark-mode');
    }
});


