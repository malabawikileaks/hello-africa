<aside id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
    <?php if (is_active_sidebar('sidebar-1')) : ?>
        <?php dynamic_sidebar('sidebar-1'); ?>
    <?php else : ?>
        <p><?php _e('Add some widgets to the sidebar to display here.', 'hello-africa'); ?></p>
    <?php endif; ?>
</aside><!-- #primary-sidebar -->
