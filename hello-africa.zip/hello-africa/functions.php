<?php
// Ensuring security by blocking direct access
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Enqueue theme styles and scripts
function hello_africa_enqueue_scripts() {
    wp_enqueue_style('hello-africa-style', get_stylesheet_uri(), [], '1.0.0');
    wp_enqueue_script('hello-africa-scripts', get_template_directory_uri() . '/assets/js/theme.js', [], '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'hello_africa_enqueue_scripts');

// Theme Support
function hello_africa_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption']);
    add_theme_support('widgets');
    add_theme_support('custom-logo');

    // Registering a custom navigation menu
    register_nav_menus([
        'primary' => __('Primary Menu', 'hello-africa')
    ]);
}
add_action('after_setup_theme', 'hello_africa_theme_setup');

// Register widget area (sidebar)
function hello_africa_widgets_init() {
    register_sidebar([
        'name'          => __('Sidebar', 'hello-africa'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here.', 'hello-africa'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ]);
}
add_action('widgets_init', 'hello_africa_widgets_init');

// Advanced search form
function hello_africa_advanced_search_form() {
    $form = '
    <form role="search" method="get" class="search-form" action="' . esc_url(home_url('/')) . '">
        <label for="search-form-advanced">
            <span class="screen-reader-text">' . _x('Search for:', 'label', 'hello-africa') . '</span>
            <input type="search" id="search-form-advanced" class="search-field" placeholder="' . esc_attr__('Search...', 'hello-africa') . '" value="' . get_search_query() . '" name="s">
        </label>
        <button type="submit" class="search-submit">' . esc_html__('Search', 'hello-africa') . '</button>
    </form>';
    return $form;
}
add_shortcode('advanced_search', 'hello_africa_advanced_search_form');
?>


